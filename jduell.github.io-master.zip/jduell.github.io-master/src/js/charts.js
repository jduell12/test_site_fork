//C3, D3 Charting Libraries
require('script!c3/c3.min');
require('script!d3/d3.min');
