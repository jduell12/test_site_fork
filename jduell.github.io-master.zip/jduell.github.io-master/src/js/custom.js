//Entry with sample less
require('../less/custom.less');